XPCImageFetcher
===============

Using a XPC service to download 5000 images and populate a NSTableView.

The XPC service download images asynchronously with cancellation support.  

[XPC Service and NSTableView](http://lianxu.me/2014/08/xpc-service-and-nstableview/)

![screenshot](https://raw.githubusercontent.com/keefo/XPCImageFetcher/master/xpcscreenshot.jpg)

![screenshot](https://raw.githubusercontent.com/keefo/XPCImageFetcher/master/screenshot.png)
