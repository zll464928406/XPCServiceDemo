//
//  NSString+MD5.h
//  iYY
//
//  Created by xu lian on 12-02-09.
//  Copyright (c) 2012 Beyondcow. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (UUID)
+ (NSString*)stringWithNewUUID;
@end
