//
//  XIFTableRowView.m
//  XPCImageFetcher
//
//  Created by liam on 2014-08-04.
//  Copyright (c) 2014 Beyondcow. All rights reserved.
//

#import "XIFTableRowView.h"

@implementation XIFTableRowView

@end
