//
//  LLBSDMessagingTests.m
//  Tests
//
//  Created by Damien DeVille on 2/1/15.
//  Copyright (c) 2015 Damien DeVille. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>

@interface LLBSDMessagingTests : XCTestCase

@end

@implementation LLBSDMessagingTests

- (void)setUp
{
    [super setUp];
}

- (void)tearDown
{
    [super tearDown];
}

- (void)testExample
{
    XCTAssert(YES, @"Pass");
}

- (void)testPerformanceExample
{
    [self measureBlock:^{
    }];
}

@end
