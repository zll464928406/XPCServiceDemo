## LLBSDMessaging

### Interprocess communication via Berkeley sockets on iOS

See this blog [post](http://ddeville.me/2015/02/interprocess-communication-on-ios-with-berkeley-sockets/) for more info.
