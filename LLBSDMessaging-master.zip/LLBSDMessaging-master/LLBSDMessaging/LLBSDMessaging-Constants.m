//
//  LLBSDMessaging-Constants.m
//  LLBSDMessaging
//
//  Created by Damien DeVille on 2/1/15.
//  Copyright (c) 2015 Damien DeVille. All rights reserved.
//

#import "LLBSDMessaging-Constants.h"

NSString * const LLBSDMessagingBundleIdentifier = @"com.ddeville.llbsdmessaging";

NSString * const LLBSDMessagingErrorDomain = @"com.ddeville.llbsdmessaging";
